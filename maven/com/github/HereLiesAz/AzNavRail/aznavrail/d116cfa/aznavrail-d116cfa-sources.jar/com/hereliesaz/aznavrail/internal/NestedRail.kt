// FILE: ./aznavrail/src/main/java/com/hereliesaz/aznavrail/internal/NestedRail.kt
package com.hereliesaz.aznavrail.internal

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.geometry.Rect
import com.hereliesaz.aznavrail.azAccent
import com.hereliesaz.aznavrail.AzNavRailButton
import com.hereliesaz.aznavrail.AzTextBoxDefaults
import com.hereliesaz.aznavrail.model.AzButtonShape
import com.hereliesaz.aznavrail.model.AzNavItem
import com.hereliesaz.aznavrail.model.AzNestedRailAlignment
import com.hereliesaz.aznavrail.model.HiddenMenuItem

/**
 * Renders a secondary popup rail anchored beside a parent [AzNavItem].
 *
 * The layout is determined by [alignment]: VERTICAL stacks items in a scrollable column;
 * HORIZONTAL lays them out in a scrollable row. Both modes cap size at 80 % of the screen
 * to force scrolling on overflow. Position is handled externally by
 * [DockedCenteredPopupPositionProvider] / [DockedHorizontalPopupPositionProvider].
 *
 * @param parentItem The host item that opened this nested rail.
 * @param items The sub-items to render inside the popup.
 * @param currentDestination The active navigation route; used to highlight matching items.
 * @param activeColor The rail-level active color applied to selected buttons.
 * @param activeClassifiers Classifier strings used for programmatic active-state.
 * @param onItemSelected Invoked with the tapped sub-item.
 * @param alignment Whether to render items vertically or horizontally.
 * @param isRightDocked Whether the rail is docked to the right (affects padding side).
 * @param helpList Forwarded from the scope for potential help-overlay integration.
 * @param onItemGloballyPositioned Reports window-space bounds of each sub-item after layout.
 * @param rotationDegrees Rotation to apply to buttons "in place".
 */
@Composable
internal fun NestedRail(
    parentItem: AzNavItem,
    items: List<AzNavItem>,
    currentDestination: String?,
    activeColor: Color,
    activeClassifiers: Set<String>,
    /** The rail's focus-highlight colour, passed down so nested items match the rail they came from. */
    focusColor: Color? = null,
    /** The rail's secondary-highlight colour. */
    secondaryColor: Color? = null,
    /** Classifiers that light a nested item's **secondary** highlight. */
    secondaryClassifiers: Set<String> = emptySet(),
    /** The rail's tertiary-highlight colour. */
    tertiaryColor: Color? = null,
    /** Classifiers that light a nested item's **tertiary** highlight. */
    tertiaryClassifiers: Set<String> = emptySet(),
    onItemSelected: (AzNavItem) -> Unit,
    alignment: AzNestedRailAlignment,
    isRightDocked: Boolean,
    helpList: Map<String, Any> = emptyMap(),
    onItemGloballyPositioned: ((String, androidx.compose.ui.geometry.Rect) -> Unit)? = null,
    rotationDegrees: Float = 0f,
    onHostExpandedChange: ((String, Boolean) -> Unit)? = null,
    itemSize: Dp = AzNavRailDefaults.ButtonWidth,
    /** The id of the nested item whose hidden menu is currently open, if any. */
    hiddenMenuOpenId: String? = null,
    /** Invoked with a nested item's id to open its hidden menu (long-press). */
    onMenuOpen: ((String) -> Unit)? = null,
    /** Invoked to close whichever nested item's hidden menu is open. */
    onHiddenMenuDismiss: (() -> Unit)? = null,
    /** Invoked when a hidden-menu list entry is tapped. */
    onHiddenMenuItemClick: ((HiddenMenuItem) -> Unit)? = null,
    /** Invoked when a hidden-menu input entry is submitted. */
    onHiddenMenuInputSubmit: ((HiddenMenuItem, String) -> Unit)? = null,
    /** Background colour for a nested item's hidden menu; [Color.Unspecified] uses the library default. */
    hiddenMenuBackgroundColor: Color = Color.Unspecified
) {
    val configuration = LocalConfiguration.current
    val maxH = (configuration.screenHeightDp * 0.8f).dp
    val maxW = (configuration.screenWidthDp * 0.8f).dp
    val hostStates = remember { mutableStateMapOf<String, Boolean>() }

    val surfaceShape = RoundedCornerShape(16.dp)
    val modifier = Modifier
        .then(if (isRightDocked) Modifier.padding(end = 16.dp) else Modifier.padding(start = 16.dp))
        .clip(surfaceShape)
        .border(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f), surfaceShape)
        .padding(8.dp)

    if (alignment == AzNestedRailAlignment.VERTICAL) {
        val scrollState = rememberScrollState()
        Column(
            modifier = modifier.heightIn(max = maxH).verticalScroll(scrollState),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            items.filter { !it.isSubItem }.forEach { item ->
                NestedItemWrapper(item, currentDestination, activeColor, activeClassifiers, onItemSelected, rotationDegrees, onItemGloballyPositioned, hostStates, items, true, onHostExpandedChange, focusColor, secondaryColor, secondaryClassifiers, tertiaryColor, tertiaryClassifiers, itemSize, hiddenMenuOpenId, onMenuOpen, onHiddenMenuDismiss, onHiddenMenuItemClick, onHiddenMenuInputSubmit, hiddenMenuBackgroundColor)
            }
        }
    } else {
        val scrollState = rememberScrollState()
        Row(
            modifier = modifier.widthIn(max = maxW).horizontalScroll(scrollState),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            items.filter { !it.isSubItem }.forEach { item ->
                NestedItemWrapper(item, currentDestination, activeColor, activeClassifiers, onItemSelected, rotationDegrees, onItemGloballyPositioned, hostStates, items, false, onHostExpandedChange, focusColor, secondaryColor, secondaryClassifiers, tertiaryColor, tertiaryClassifiers, itemSize, hiddenMenuOpenId, onMenuOpen, onHiddenMenuDismiss, onHiddenMenuItemClick, onHiddenMenuInputSubmit, hiddenMenuBackgroundColor)
            }
        }
    }
}

@Composable
private fun NestedItemWrapper(
    item: AzNavItem,
    currentDestination: String?,
    activeColor: Color,
    activeClassifiers: Set<String>,
    onItemSelected: (AzNavItem) -> Unit,
    rotationDegrees: Float,
    onItemGloballyPositioned: ((String, androidx.compose.ui.geometry.Rect) -> Unit)?,
    hostStates: MutableMap<String, Boolean>,
    allItems: List<AzNavItem>,
    isVerticalRail: Boolean,
    onHostExpandedChange: ((String, Boolean) -> Unit)? = null,
    focusColor: Color? = null,
    secondaryColor: Color? = null,
    secondaryClassifiers: Set<String> = emptySet(),
    tertiaryColor: Color? = null,
    tertiaryClassifiers: Set<String> = emptySet(),
    itemSize: Dp = AzNavRailDefaults.ButtonWidth,
    hiddenMenuOpenId: String? = null,
    onMenuOpen: ((String) -> Unit)? = null,
    onHiddenMenuDismiss: (() -> Unit)? = null,
    onHiddenMenuItemClick: ((HiddenMenuItem) -> Unit)? = null,
    onHiddenMenuInputSubmit: ((HiddenMenuItem, String) -> Unit)? = null,
    hiddenMenuBackgroundColor: Color = Color.Unspecified
) {
    // Evict cached bounds when this nested item leaves composition (popup closes). Without
    // this the help overlay would later draw cards/lines for the now-invisible nested rail.
    DisposableEffect(item.id) {
        onDispose { onItemGloballyPositioned?.invoke(item.id, Rect.Zero) }
    }
    // Window-space bounds of this item's button, kept locally so its hidden menu (opened via
    // long-press below) can anchor itself without needing the top-level item-bounds cache.
    var itemBounds by remember { mutableStateOf(Rect.Zero) }
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        androidx.compose.foundation.layout.Box(modifier = Modifier.onGloballyPositioned { coords ->
            // positionInWindow + size so the bounds stay logical (unclipped) when the popup
            // is scrolled. See the matching comment in RailContent.kt.
            val pos = coords.positionInWindow()
            val size = coords.size
            val bounds = Rect(
                left = pos.x,
                top = pos.y,
                right = pos.x + size.width,
                bottom = pos.y + size.height,
            )
            itemBounds = bounds
            onItemGloballyPositioned?.invoke(item.id, bounds)
        }) {
            val alert = item.alert
            AzNavRailButton(
                onClick = {
                    if (item.isHost) {
                        val newHostState = !(hostStates[item.id] ?: false)
                        hostStates[item.id] = newHostState
                        onHostExpandedChange?.invoke(item.id, newHostState)
                    } else {
                        onItemSelected(item)
                    }
                },
                onLongClick = if (!item.hiddenMenuItems.isNullOrEmpty()) {
                    { onMenuOpen?.invoke(item.id) }
                } else null,
                text = item.text,
                color = alert?.color() ?: item.color ?: azAccent(),
                activeColor = alert?.color() ?: activeColor,
                textColor = if (alert != null) alert.color() else item.textColor,
                fillColor = item.fillColor,
                backgroundColor = item.translucentBackgroundColor,
                shape = if (alert != null) AzButtonShape.TRIANGLE else (item.shape ?: AzButtonShape.CIRCLE),
                size = itemSize,
                enabled = !item.disabled,
                isSelected = (item.route != null && currentDestination == item.route) || item.classifiers.any { activeClassifiers.contains(it) },
                isSecondaryActive = item.isSecondaryActive ||
                    item.classifiers.any { secondaryClassifiers.contains(it) },
                isTertiaryActive = item.isTertiaryActive ||
                    item.classifiers.any { tertiaryClassifiers.contains(it) },
                focusColor = item.focusColor ?: focusColor,
                secondaryColor = item.secondaryColor ?: secondaryColor,
                tertiaryColor = item.tertiaryColor ?: tertiaryColor,
                isLoading = item.isLoading,
                itemContent = if (alert != null) null else item.content,
                rotationDegrees = rotationDegrees
            )

            // Nested-rail children carry badges too — they are rail items like any other, and used
            // to be the one place a declared badge was silently dropped.
            val showBadge = androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
            androidx.compose.runtime.LaunchedEffect(item.badge) {
                if (!item.badge.isNullOrBlank()) {
                    showBadge.value = true
                    if (!item.persistentBadge) {
                        kotlinx.coroutines.delay(1000)
                        showBadge.value = false
                    }
                } else {
                    showBadge.value = false
                }
            }
            if (showBadge.value && !item.badge.isNullOrBlank()) {
                com.hereliesaz.aznavrail.AzBadge(
                    text = item.badge,
                    modifier = Modifier.align(Alignment.TopEnd),
                    containerColor = item.color ?: activeColor,
                )
            }
        }

        if (hiddenMenuOpenId == item.id && !item.hiddenMenuItems.isNullOrEmpty()) {
            HiddenMenuPopup(
                items = item.hiddenMenuItems,
                onDismiss = {
                    item.onHiddenMenuDismiss?.invoke()
                    onHiddenMenuDismiss?.invoke()
                },
                onItemClick = { menuItem ->
                    onHiddenMenuItemClick?.invoke(menuItem)
                    item.onHiddenMenuDismiss?.invoke()
                    onHiddenMenuDismiss?.invoke()
                },
                onInputSubmit = { menuItem, value ->
                    onHiddenMenuInputSubmit?.invoke(menuItem, value)
                    item.onHiddenMenuDismiss?.invoke()
                    onHiddenMenuDismiss?.invoke()
                },
                backgroundColor = if (hiddenMenuBackgroundColor != Color.Unspecified) hiddenMenuBackgroundColor else AzTextBoxDefaults.getBackgroundColor(),
                backgroundOpacity = AzTextBoxDefaults.getBackgroundOpacity(),
                anchorWidth = itemBounds.right.toInt(),
                anchorTop = itemBounds.top.toInt(),
                accent = activeColor,
            )
        }

        if (item.isHost && hostStates[item.id] == true) {
            val subItems = allItems.filter { it.hostId == item.id && it.isSubItem }
            if (isVerticalRail) {
                // Vertical rail: sub-items continue the column
                subItems.forEach { subItem ->
                    NestedItemWrapper(subItem, currentDestination, activeColor, activeClassifiers, onItemSelected, rotationDegrees, onItemGloballyPositioned, hostStates, allItems, isVerticalRail, null, focusColor, secondaryColor, secondaryClassifiers, tertiaryColor, tertiaryClassifiers, itemSize, hiddenMenuOpenId, onMenuOpen, onHiddenMenuDismiss, onHiddenMenuItemClick, onHiddenMenuInputSubmit, hiddenMenuBackgroundColor)
                }
            } else {
                // Horizontal rail: sub-items expand downward vertically
                Column(
                    modifier = Modifier.padding(top = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    subItems.forEach { subItem ->
                        NestedItemWrapper(subItem, currentDestination, activeColor, activeClassifiers, onItemSelected, rotationDegrees, onItemGloballyPositioned, hostStates, allItems, isVerticalRail, null, focusColor, secondaryColor, secondaryClassifiers, tertiaryColor, tertiaryClassifiers, itemSize, hiddenMenuOpenId, onMenuOpen, onHiddenMenuDismiss, onHiddenMenuItemClick, onHiddenMenuInputSubmit, hiddenMenuBackgroundColor)
                    }
                }
            }
        }
    }
}
