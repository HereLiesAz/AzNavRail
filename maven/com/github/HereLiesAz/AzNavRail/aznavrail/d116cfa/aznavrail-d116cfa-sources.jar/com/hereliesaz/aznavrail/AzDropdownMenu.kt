package com.hereliesaz.aznavrail

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.takeOrElse
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Easing
import androidx.compose.animation.core.tween
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.isSpecified
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupPositionProvider
import androidx.compose.ui.window.PopupProperties
import androidx.navigation.NavController
import coil.compose.rememberAsyncImagePainter
import com.hereliesaz.aznavrail.internal.AboutOverlay
import com.hereliesaz.aznavrail.internal.AZ_INSTAGRAM_URL
import com.hereliesaz.aznavrail.internal.AzAboutRegistry
import com.hereliesaz.aznavrail.internal.AzAboutSurface
import com.hereliesaz.aznavrail.internal.AzFooterLabel
import com.hereliesaz.aznavrail.internal.rememberAzAboutOwnership
import com.hereliesaz.aznavrail.internal.AzNavRailDefaults
import com.hereliesaz.aznavrail.internal.AzSafeZones
import com.hereliesaz.aznavrail.internal.azWindowSafeInsets
import com.hereliesaz.aznavrail.internal.MoreFromAzOverlay
import com.hereliesaz.aznavrail.service.GithubDocsRepository
import com.hereliesaz.aznavrail.model.AzMotion
import com.hereliesaz.aznavrail.model.AzButtonShape
import com.hereliesaz.aznavrail.model.AzDockingSide
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.unit.IntRect
import com.hereliesaz.aznavrail.internal.AzDropdownTriggerButton
import com.hereliesaz.aznavrail.internal.AzDropdownTriggerSpec
import com.hereliesaz.aznavrail.internal.AzTitleTriggerSlot
import com.hereliesaz.aznavrail.model.AzDropdownDesign
import com.hereliesaz.aznavrail.model.AzDropdownTrigger
import com.hereliesaz.aznavrail.model.AzDropdownTriggerPlacement
import com.hereliesaz.aznavrail.model.AzEasing
import com.hereliesaz.aznavrail.model.AzEntrance
import com.hereliesaz.aznavrail.model.AzExit
import com.hereliesaz.aznavrail.model.AzHeaderIconShape
import com.hereliesaz.aznavrail.internal.rememberAzKineticModifier
import com.hereliesaz.aznavrail.internal.rememberAzClosingState

/**
 * DSL builder scope for an [AzDropdownMenu] — declared the same way as the rail
 * (`AzDropdownMenu { azConfig(...); azItem(...) { } }`).
 *
 * In keeping with AzNavRail's opinionated tradition, the drop-down only accepts configuration the
 * rest of the library sanctions: [azConfig] mirrors the rail's `azConfig`/`azTheme` (design, docking
 * side, vibration, the collapsed/expanded widths, and the app-icon shape/size) and the item builders
 * accept only the per-item knobs the rail's items accept (`color`/`textColor`/`fillColor`/`shape`/
 * `enabled`, plus a navigation `route`). There is no arbitrary panel background, offset, or free
 * composable escape hatch.
 */
interface AzDropdownMenuScope {
    /**
     * Configures the panel, mirroring the rail's `azConfig`/`azTheme`. Call at most once.
     *
     * @param design Whether the panel imitates the collapsed [AzDropdownDesign.RAIL] (compact rail
     *   buttons at [collapsedWidth]) or the expanded [AzDropdownDesign.MENU] (labeled rows at
     *   [expandedWidth]).
     * @param dockingSide Which screen edge the panel pins to ([AzDockingSide.LEFT]/[AzDockingSide.RIGHT]).
     * @param vibrate Haptic feedback when the trigger is tapped.
     * @param expandedWidth Panel width in the [AzDropdownDesign.MENU] design.
     * @param collapsedWidth Panel width in the [AzDropdownDesign.RAIL] design.
     * @param headerIconShape Clip shape for the app-icon trigger (mirrors the rail's
     *   `azTheme(headerIconShape = …)`).
     * @param headerIconSize Diameter of the app-icon trigger (mirrors the rail's
     *   `azTheme(headerIconSize = …)`).
     * @param showFooter Whether the [AzDropdownDesign.MENU] panel shows the rail's footer
     *   (About / Feedback / @HereLiesAz), like the rail's expanded menu.
     * @param inAppAbout When true (the default), the footer's "About" opens a full-screen, in-app
     *   markdown reader auto-generated from the host app's repo (the dropdown has no onscreen area,
     *   so it draws its own full-screen layer). When false, "About" opens the repo in a browser.
     * @param dedupeAbout When true (the default) this footer drops its "About" row whenever a
     *   higher-ranked surface — a developer-declared `?` rail item, or a rail's own expanded-menu
     *   footer — is already offering one, so the app never shows About twice. Set false to always
     *   draw it (and to stop this menu suppressing anyone else's).
     * @param appRepositoryUrl Optional explicit override for the host app's GitHub repository used by
     *   the "About" screen. Blank (the default) auto-derives it from the app namespace
     *   (`com.<owner>.<repo>` → `github.com/<owner>/<repo>`); never the AzNavRail library repo.
     * @param itemTextStyle Optional override merged over each item's label style (lets the menu words
     *   be big/light/wide Metro type). Applied to the [AzDropdownDesign.MENU] rows; [AzDropdownDesign.RAIL]
     *   items keep their auto-sized text.
     * @param itemEntrance Windows-Phone-7-style entrance played as the panel opens (see [AzEntrance]);
     *   defaults to [AzEntrance.Turnstile]. Pass [AzEntrance.None] for a static panel.
     * @param entranceStaggerMs Per-item cascade delay, multiplied by the item's position.
     * @param entranceDurationMs Duration of each item's entrance/exit animation.
     * @param entranceEasing Easing for the entrance/exit (defaults to [AzEasing.Wp7Decelerate]).
     * @param entranceStartAngle Starting `rotationY` for the [AzEntrance.Turnstile] sweep, in degrees.
     * @param tiltOnPress When true, items tilt in 3D toward the press point and spring back on release
     *   (the WP7 "tilt effect"); the item's `onClick` still fires.
     * @param maxTiltDegrees Maximum tilt angle for [tiltOnPress].
     * @param itemExit Exit played as the panel dismisses (see [AzExit]); defaults to [AzExit.Turnstile].
     *   Items are held mounted through the close so they can animate out.
     * @param trigger What the user taps to open the menu. Defaults to [AzDropdownTrigger.MoreVert] —
     *   the three vertical dots. Pass [AzDropdownTrigger.Text] for a word, [AzDropdownTrigger.Icon]
     *   for your own glyph/image, [AzDropdownTrigger.Hamburger] for the bars, or
     *   [AzDropdownTrigger.AppIcon] for the launcher icon (the pre-trigger default). The trigger's
     *   size and clip shape come from [headerIconSize] / [headerIconShape].
     * @param triggerPlacement Where that trigger is drawn. [AzDropdownTriggerPlacement.AUTO] (the
     *   default) lifts it up next to the big screen title, above the onscreen content area, whenever
     *   the drop-down is declared inside an `AzHostActivityLayout`; standalone drop-downs stay
     *   inline. Several title-hosted drop-downs line their triggers up beside each other in
     *   declaration order. Force either behaviour with [AzDropdownTriggerPlacement.TITLE] /
     *   [AzDropdownTriggerPlacement.INLINE].
     */
    fun azConfig(
        design: AzDropdownDesign = AzDropdownDesign.MENU,
        dockingSide: AzDockingSide = AzDockingSide.LEFT,
        vibrate: Boolean = false,
        expandedWidth: Dp = 160.dp,
        collapsedWidth: Dp = 100.dp,
        headerIconShape: AzHeaderIconShape = AzHeaderIconShape.CIRCLE,
        headerIconSize: Dp = 48.dp,
        showFooter: Boolean = true,
        inAppAbout: Boolean = true,
        dedupeAbout: Boolean = true,
        appRepositoryUrl: String = "",
        itemTextStyle: TextStyle? = null,
        itemEntrance: AzEntrance = AzEntrance.Turnstile,
        entranceStaggerMs: Int = AzMotion.ItemStaggerMs,
        entranceDurationMs: Int = AzMotion.ItemDurationMs,
        entranceEasing: Easing = AzEasing.Wp7Decelerate,
        entranceStartAngle: Float = 90f,
        tiltOnPress: Boolean = false,
        maxTiltDegrees: Float = 10f,
        itemExit: AzExit = AzExit.Turnstile,
        dimBehindMenu: Boolean = false,
        dimBehindMenuAlpha: Float = 0.4f,
        menuItemAlignment: com.hereliesaz.aznavrail.model.AzMenuItemAlignment =
            com.hereliesaz.aznavrail.model.AzMenuItemAlignment.SIDE,
        justifyMenuItems: Boolean = true,
        trigger: AzDropdownTrigger = AzDropdownTrigger.MoreVert,
        triggerPlacement: AzDropdownTriggerPlacement = AzDropdownTriggerPlacement.AUTO,
    )

    /**
     * A tappable entry. Navigates to [route] (if set, via the menu's `navController`), runs [onClick],
     * then folds the menu up when [closeOnClick] is true (the default).
     */
    fun azItem(
        text: String,
        route: String? = null,
        color: Color = Color.Unspecified,
        textColor: Color? = null,
        fillColor: Color? = null,
        shape: AzButtonShape = AzButtonShape.RECTANGLE,
        enabled: Boolean = true,
        closeOnClick: Boolean = true,
        onClick: () -> Unit = {}
    )

    /** A two-state entry. Stays open by default. */
    fun azToggle(
        isChecked: Boolean,
        toggleOnText: String,
        toggleOffText: String,
        route: String? = null,
        color: Color = Color.Unspecified,
        textColor: Color? = null,
        fillColor: Color? = null,
        shape: AzButtonShape = AzButtonShape.RECTANGLE,
        enabled: Boolean = true,
        closeOnClick: Boolean = false,
        onToggle: (Boolean) -> Unit
    )

    /** A rotating entry. Stays open by default. */
    fun azCycler(
        options: List<String>,
        selectedOption: String,
        route: String? = null,
        color: Color = Color.Unspecified,
        textColor: Color? = null,
        fillColor: Color? = null,
        shape: AzButtonShape = AzButtonShape.RECTANGLE,
        enabled: Boolean = true,
        closeOnClick: Boolean = false,
        onCycle: (String) -> Unit
    )

    /** A separator rendered as an [AzDivider]. */
    fun azDivider()
}

/** Resolved drop-down configuration collected from [AzDropdownMenuScope.azConfig]. */
internal data class AzDropdownConfig(
    val design: AzDropdownDesign = AzDropdownDesign.MENU,
    val dockingSide: AzDockingSide = AzDockingSide.LEFT,
    val vibrate: Boolean = false,
    val expandedWidth: Dp = 160.dp,
    val collapsedWidth: Dp = 100.dp,
    val headerIconShape: AzHeaderIconShape = AzHeaderIconShape.CIRCLE,
    val headerIconSize: Dp = 48.dp,
    val showFooter: Boolean = true,
    val inAppAbout: Boolean = true,
    val dedupeAbout: Boolean = true,
    val appRepositoryUrl: String = "",
    val itemTextStyle: TextStyle? = null,
    val itemEntrance: AzEntrance = AzEntrance.Turnstile,
    val entranceStaggerMs: Int = AzMotion.ItemStaggerMs,
    val entranceDurationMs: Int = AzMotion.ItemDurationMs,
    val entranceEasing: Easing = AzEasing.Wp7Decelerate,
    val entranceStartAngle: Float = 90f,
    val tiltOnPress: Boolean = false,
    val maxTiltDegrees: Float = 10f,
    val itemExit: AzExit = AzExit.Turnstile,
    val dimBehindMenu: Boolean = false,
    val dimBehindMenuAlpha: Float = 0.4f,
    val menuItemAlignment: com.hereliesaz.aznavrail.model.AzMenuItemAlignment =
        com.hereliesaz.aznavrail.model.AzMenuItemAlignment.SIDE,
    val justifyMenuItems: Boolean = true,
    val trigger: AzDropdownTrigger = AzDropdownTrigger.MoreVert,
    val triggerPlacement: AzDropdownTriggerPlacement = AzDropdownTriggerPlacement.AUTO,
)

/** One declared entry, collected by the builder and rendered by the composable. */
internal sealed interface AzDropdownEntry {
    val route: String?

    data class Item(
        val text: String,
        override val route: String?,
        val color: Color,
        val textColor: Color?,
        val fillColor: Color?,
        val shape: AzButtonShape,
        val enabled: Boolean,
        val closeOnClick: Boolean,
        val onClick: () -> Unit
    ) : AzDropdownEntry

    data class Toggle(
        val isChecked: Boolean,
        val toggleOnText: String,
        val toggleOffText: String,
        override val route: String?,
        val color: Color,
        val textColor: Color?,
        val fillColor: Color?,
        val shape: AzButtonShape,
        val enabled: Boolean,
        val closeOnClick: Boolean,
        val onToggle: (Boolean) -> Unit
    ) : AzDropdownEntry

    data class Cycler(
        val options: List<String>,
        val selectedOption: String,
        override val route: String?,
        val color: Color,
        val textColor: Color?,
        val fillColor: Color?,
        val shape: AzButtonShape,
        val enabled: Boolean,
        val closeOnClick: Boolean,
        val onCycle: (String) -> Unit
    ) : AzDropdownEntry

    object Divider : AzDropdownEntry {
        override val route: String? = null
    }
}

/**
 * Collects the [azConfig] result and the declared entries. Like the rail's scope, it is a plain
 * (non-`@Composable`) builder; the composable creates a fresh one each recomposition, runs the DSL
 * over it, then renders from [config] and [entries].
 */
private class AzDropdownMenuScopeImpl : AzDropdownMenuScope {
    var config = AzDropdownConfig()
        private set
    val entries = mutableListOf<AzDropdownEntry>()

    override fun azConfig(
        design: AzDropdownDesign,
        dockingSide: AzDockingSide,
        vibrate: Boolean,
        expandedWidth: Dp,
        collapsedWidth: Dp,
        headerIconShape: AzHeaderIconShape,
        headerIconSize: Dp,
        showFooter: Boolean,
        inAppAbout: Boolean,
        dedupeAbout: Boolean,
        appRepositoryUrl: String,
        itemTextStyle: TextStyle?,
        itemEntrance: AzEntrance,
        entranceStaggerMs: Int,
        entranceDurationMs: Int,
        entranceEasing: Easing,
        entranceStartAngle: Float,
        tiltOnPress: Boolean,
        maxTiltDegrees: Float,
        itemExit: AzExit,
        dimBehindMenu: Boolean,
        dimBehindMenuAlpha: Float,
        menuItemAlignment: com.hereliesaz.aznavrail.model.AzMenuItemAlignment,
        justifyMenuItems: Boolean,
        trigger: AzDropdownTrigger,
        triggerPlacement: AzDropdownTriggerPlacement,
    ) {
        config = AzDropdownConfig(
            design, dockingSide, vibrate, expandedWidth, collapsedWidth, headerIconShape, headerIconSize,
            showFooter, inAppAbout, dedupeAbout, appRepositoryUrl, itemTextStyle, itemEntrance, entranceStaggerMs,
            entranceDurationMs, entranceEasing, entranceStartAngle, tiltOnPress, maxTiltDegrees, itemExit,
            dimBehindMenu, dimBehindMenuAlpha, menuItemAlignment, justifyMenuItems, trigger, triggerPlacement,
        )
    }

    override fun azItem(
        text: String,
        route: String?,
        color: Color,
        textColor: Color?,
        fillColor: Color?,
        shape: AzButtonShape,
        enabled: Boolean,
        closeOnClick: Boolean,
        onClick: () -> Unit
    ) {
        entries += AzDropdownEntry.Item(text, route, color, textColor, fillColor, shape, enabled, closeOnClick, onClick)
    }

    override fun azToggle(
        isChecked: Boolean,
        toggleOnText: String,
        toggleOffText: String,
        route: String?,
        color: Color,
        textColor: Color?,
        fillColor: Color?,
        shape: AzButtonShape,
        enabled: Boolean,
        closeOnClick: Boolean,
        onToggle: (Boolean) -> Unit
    ) {
        entries += AzDropdownEntry.Toggle(
            isChecked, toggleOnText, toggleOffText, route, color, textColor, fillColor, shape, enabled, closeOnClick, onToggle
        )
    }

    override fun azCycler(
        options: List<String>,
        selectedOption: String,
        route: String?,
        color: Color,
        textColor: Color?,
        fillColor: Color?,
        shape: AzButtonShape,
        enabled: Boolean,
        closeOnClick: Boolean,
        onCycle: (String) -> Unit
    ) {
        entries += AzDropdownEntry.Cycler(
            options, selectedOption, route, color, textColor, fillColor, shape, enabled, closeOnClick, onCycle
        )
    }

    override fun azDivider() {
        entries += AzDropdownEntry.Divider
    }
}

/**
 * Resolves the row text colour: an explicit [textColor] or [color] is used exactly as declared,
 * otherwise the panel's own [accent] — the rail's, already checked against the panel it lands on
 * (see [azReadableOn]). A menu whose words disappear into its own background is not a menu.
 */
private fun effectiveTextColor(textColor: Color?, color: Color, accent: Color): Color =
    (textColor ?: color).takeOrElse { accent }

/**
 * A full-width, labeled menu row mirroring the expanded drawer's look (centred [titleLarge] text,
 * the menu's horizontal/vertical padding). Used for [AzDropdownDesign.MENU] items.
 */
@Composable
private fun AzDropdownMenuRow(
    text: String,
    enabled: Boolean,
    textColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    textStyle: TextStyle? = null,
    dockingSide: AzDockingSide = AzDockingSide.LEFT,
    menuItemAlignment: com.hereliesaz.aznavrail.model.AzMenuItemAlignment =
        com.hereliesaz.aznavrail.model.AzMenuItemAlignment.SIDE,
    justifyMenuItems: Boolean = true,
) {
    val textAlign = when (menuItemAlignment) {
        com.hereliesaz.aznavrail.model.AzMenuItemAlignment.CENTER -> TextAlign.Center
        com.hereliesaz.aznavrail.model.AzMenuItemAlignment.SIDE ->
            if (dockingSide == AzDockingSide.RIGHT) TextAlign.End else TextAlign.Start
    }
    val columnAlignment = when (menuItemAlignment) {
        com.hereliesaz.aznavrail.model.AzMenuItemAlignment.CENTER -> Alignment.CenterHorizontally
        com.hereliesaz.aznavrail.model.AzMenuItemAlignment.SIDE ->
            if (dockingSide == AzDockingSide.RIGHT) Alignment.End else Alignment.Start
    }
    val mergedStyle = MaterialTheme.typography.titleLarge.merge(textStyle)
    val textMeasurer = androidx.compose.ui.text.rememberTextMeasurer()
    val density = androidx.compose.ui.platform.LocalDensity.current

    Row(
        modifier = modifier
            .fillMaxWidth()
            .then(if (enabled) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(
                horizontal = AzNavRailDefaults.MenuItemHorizontalPadding,
                vertical = AzNavRailDefaults.MenuItemVerticalPadding
            ),
        verticalAlignment = Alignment.CenterVertically
    ) {
        androidx.compose.foundation.layout.BoxWithConstraints(Modifier.weight(1f)) {
            val availableWidthPx = with(density) { maxWidth.toPx() }
            val baseFontSizePx = with(density) {
                val fs = mergedStyle.fontSize
                if (fs.isSpecified) fs.toPx()
                else MaterialTheme.typography.titleLarge.fontSize.toPx()
            }
            Column(horizontalAlignment = columnAlignment) {
                text.split('\n').forEach { line ->
                    val (scale, kerningPx) = if (!justifyMenuItems || line.length < 2) 1f to 0f
                    else {
                        val naturalWidthPx = try {
                            textMeasurer.measure(text = line, style = mergedStyle).size.width.toFloat()
                        } catch (_: Throwable) { availableWidthPx }
                        com.hereliesaz.aznavrail.internal.solveHybridJustify(
                            naturalWidthPx = naturalWidthPx,
                            rowWidthPx = availableWidthPx,
                            charCount = line.length,
                            baseFontSizePx = baseFontSizePx,
                        )
                    }
                    val scaledFontSize = if (scale == 1f) mergedStyle.fontSize
                        else with(density) { (baseFontSizePx * scale).toSp() }
                    Text(
                        text = line,
                        style = mergedStyle.copy(fontSize = scaledFontSize),
                        color = if (enabled) textColor else textColor.copy(alpha = 0.5f),
                        textAlign = textAlign,
                        letterSpacing = with(density) { kerningPx.toSp() },
                        modifier = Modifier.fillMaxWidth(),
                        // Explicit-only line breaks; the solver's shrink branch handles oversized
                        // labels by scaling the font down instead of wrapping mid-word.
                        softWrap = false,
                        maxLines = 1,
                        overflow = TextOverflow.Clip,
                    )
                }
            }
        }
    }
}

/**
 * The drop-down's footer for the [AzDropdownDesign.MENU] design — mirrors the rail's footer
 * ([com.hereliesaz.aznavrail.internal.Footer]): About, Feedback (email), and the @HereLiesAz
 * attribution. Centred [titleLarge] text in the theme primary, like the rail.
 *
 * @param repoUrl The effective host-app repository (explicit override or namespace-derived) opened
 *   by "About" when the in-app reader is disabled.
 * @param onAboutClick When non-null, "About" opens the in-app reader via this callback instead of a
 *   browser.
 * @param footerColor The panel's resolved, legible accent — the same colour its item rows wear.
 */
@Composable
private fun AzDropdownFooter(
    repoUrl: String,
    onAboutClick: (() -> Unit)?,
    footerColor: Color,
    /** False when a higher-ranked surface already offers About — see [AzAboutRegistry]. */
    showAbout: Boolean = true,
    visible: Boolean = true,
    menuItemCount: Int = 0,
    staggerMs: Int = AzMotion.ItemStaggerMs,
    durationMs: Int = AzMotion.ItemDurationMs,
    easing: Easing = AzEasing.Wp7Decelerate,
) {
    val context = LocalContext.current
    val appName = remember(context.packageName) {
        try {
            context.packageManager.getApplicationLabel(
                context.packageManager.getApplicationInfo(context.packageName, 0)
            ).toString()
        } catch (e: Exception) {
            "App"
        }
    }

    // Always start collapsed so the first composition plays the fold-in animation. Previous
    // `if (visible) 1f else 0f` meant the footer was already visible on first mount and no
    // animation ever played.
    val scaleY = remember { Animatable(0f) }
    val fade = remember { Animatable(0f) }
    LaunchedEffect(visible) {
        val spec = tween<Float>(durationMillis = durationMs, easing = easing)
        if (visible) {
            // One stagger tick beyond the last item's start — the footer is the next beat.
            delay(menuItemCount.coerceAtLeast(0).toLong() * staggerMs)
            launch { scaleY.animateTo(1f, spec) }
            launch { fade.animateTo(1f, spec) }
        } else {
            // On close the footer is the FIRST to go — fold up immediately so the items can begin
            // their bottom-up exit cascade in its wake.
            launch { scaleY.animateTo(0f, spec) }
            launch { fade.animateTo(0f, spec) }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .graphicsLayer {
                this.scaleY = scaleY.value
                this.alpha = fade.value
                transformOrigin = TransformOrigin(0.5f, 0f)
            }
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if (showAbout) {
            AzFooterLabel(
                text = "About",
                color = footerColor,
                onClick = {
                    if (onAboutClick != null) {
                        onAboutClick()
                    } else {
                        // Only follow plain web URLs, never an injected scheme (e.g. javascript:/content:).
                        val isHttp = repoUrl.startsWith("http://", ignoreCase = true) ||
                            repoUrl.startsWith("https://", ignoreCase = true)
                        if (isHttp) {
                            try {
                                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(repoUrl)))
                            } catch (e: Exception) {}
                        }
                    }
                },
                modifier = Modifier.padding(vertical = 4.dp),
            )
            Spacer(modifier = Modifier.height(16.dp))
        }
        AzFooterLabel(
            text = "Feedback",
            color = footerColor,
            onClick = {
                try {
                    val emailIntent = Intent(Intent.ACTION_SENDTO).apply {
                        data = Uri.parse("mailto:hereliesaz@gmail.com")
                        putExtra(Intent.EXTRA_SUBJECT, appName)
                    }
                    context.startActivity(Intent.createChooser(emailIntent, "Send feedback"))
                } catch (e: Exception) {}
            },
            modifier = Modifier.padding(vertical = 4.dp),
        )
        Spacer(modifier = Modifier.height(16.dp))
        AzFooterLabel(
            text = "@HereLiesAz",
            // Same accent as the other footer rows.
            color = footerColor,
            onClick = {
                try {
                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(AZ_INSTAGRAM_URL)))
                } catch (e: Exception) {}
            },
            modifier = Modifier.padding(vertical = 4.dp),
        )
    }
}

/** Renders one collected [AzDropdownEntry] in the panel, wiring navigation + dismissal. */
@Composable
private fun AzDropdownEntryItem(
    index: Int,
    count: Int,
    visible: Boolean,
    entry: AzDropdownEntry,
    config: AzDropdownConfig,
    navController: NavController?,
    // The panel's resolved, legible accent — what an item that declared no colour of its own wears.
    accent: Color,
    dismiss: () -> Unit,
    // Captures each entry's true window-space bounds so the dissolve overlay can render at the
    // right screen position after the panel Popup tears down. Called from `.onGloballyPositioned`.
    onBoundsCapture: (Int, androidx.compose.ui.geometry.Rect) -> Unit = { _, _ -> },
    // Fires just before `dismiss()` when the tapped entry closes the panel — the outer composable
    // uses it to spawn a `DissolveOverlay` with the entry's captured bounds.
    onDissolveTap: (Int, String) -> Unit = { _, _ -> },
) {
    val design = config.design
    fun navigate(route: String?) {
        route?.let { navController?.navigate(it) }
    }

    // Dividers carry no kinetics; everything else gets the staggered entrance/exit + optional tilt.
    if (entry is AzDropdownEntry.Divider) {
        AzDivider(color = accent)
        return
    }

    val kinetic = rememberAzKineticModifier(
        index = index,
        count = count,
        visible = visible,
        entrance = config.itemEntrance,
        exit = config.itemExit,
        staggerMs = config.entranceStaggerMs,
        durationMs = config.entranceDurationMs,
        easing = config.entranceEasing,
        startAngle = config.entranceStartAngle,
        tiltOnPress = config.tiltOnPress,
        maxTiltDegrees = config.maxTiltDegrees,
        dockingSide = config.dockingSide
    )

    // Capture the entry's true window-space bounds so the dissolve overlay can render at the
    // right screen position after the panel Popup tears down.
    val boundsModifier = Modifier.onGloballyPositioned { coordinates ->
        val pos = coordinates.positionInWindow()
        val size = coordinates.size
        onBoundsCapture(
            index,
            androidx.compose.ui.geometry.Rect(
                left = pos.x,
                top = pos.y,
                right = pos.x + size.width,
                bottom = pos.y + size.height,
            ),
        )
    }

    Box(modifier = boundsModifier) {
    when (entry) {
        is AzDropdownEntry.Item -> {
            val action = {
                navigate(entry.route)
                entry.onClick()
                if (entry.closeOnClick) {
                    onDissolveTap(index, entry.text)
                    dismiss()
                }
            }
            if (design == AzDropdownDesign.MENU) {
                AzDropdownMenuRow(
                    text = entry.text,
                    enabled = entry.enabled,
                    textColor = effectiveTextColor(entry.textColor, entry.color, accent),
                    onClick = action,
                    modifier = kinetic,
                    textStyle = config.itemTextStyle,
                    dockingSide = config.dockingSide,
                    menuItemAlignment = config.menuItemAlignment,
                    justifyMenuItems = config.justifyMenuItems,
                )
            } else {
                Box(modifier = kinetic) {
                    AzButton(
                        onClick = action,
                        text = entry.text,
                        color = entry.color.takeOrElse { accent },
                        textColor = entry.textColor,
                        fillColor = entry.fillColor,
                        shape = entry.shape,
                        enabled = entry.enabled
                    )
                }
            }
        }

        is AzDropdownEntry.Toggle -> {
            if (design == AzDropdownDesign.MENU) {
                AzDropdownMenuRow(
                    text = if (entry.isChecked) entry.toggleOnText else entry.toggleOffText,
                    enabled = entry.enabled,
                    textColor = effectiveTextColor(entry.textColor, entry.color, accent),
                    onClick = {
                        navigate(entry.route)
                        entry.onToggle(!entry.isChecked)
                        if (entry.closeOnClick) {
                            onDissolveTap(index, entryLabel(entry))
                            dismiss()
                        }
                    },
                    modifier = kinetic,
                    textStyle = config.itemTextStyle,
                    dockingSide = config.dockingSide,
                    menuItemAlignment = config.menuItemAlignment,
                    justifyMenuItems = config.justifyMenuItems,
                )
            } else {
                Box(modifier = kinetic) {
                    AzToggle(
                        isChecked = entry.isChecked,
                        onToggle = {
                            navigate(entry.route)
                            entry.onToggle(it)
                            if (entry.closeOnClick) {
                                onDissolveTap(index, entryLabel(entry))
                                dismiss()
                            }
                        },
                        toggleOnText = entry.toggleOnText,
                        toggleOffText = entry.toggleOffText,
                        color = entry.color.takeOrElse { accent },
                        textColor = entry.textColor,
                        fillColor = entry.fillColor,
                        shape = entry.shape,
                        enabled = entry.enabled
                    )
                }
            }
        }

        is AzDropdownEntry.Cycler -> {
            if (design == AzDropdownDesign.MENU) {
                AzDropdownMenuRow(
                    text = entry.selectedOption,
                    enabled = entry.enabled,
                    textColor = effectiveTextColor(entry.textColor, entry.color, accent),
                    onClick = {
                        if (entry.options.isNotEmpty()) {
                            val next = entry.options[(entry.options.indexOf(entry.selectedOption) + 1).mod(entry.options.size)]
                            navigate(entry.route)
                            entry.onCycle(next)
                        }
                        if (entry.closeOnClick) {
                            onDissolveTap(index, entryLabel(entry))
                            dismiss()
                        }
                    },
                    modifier = kinetic,
                    textStyle = config.itemTextStyle,
                    dockingSide = config.dockingSide,
                    menuItemAlignment = config.menuItemAlignment,
                    justifyMenuItems = config.justifyMenuItems,
                )
            } else {
                Box(modifier = kinetic) {
                    AzCycler(
                        options = entry.options,
                        selectedOption = entry.selectedOption,
                        onCycle = {
                            navigate(entry.route)
                            entry.onCycle(it)
                            if (entry.closeOnClick) {
                                onDissolveTap(index, entryLabel(entry))
                                dismiss()
                            }
                        },
                        color = entry.color.takeOrElse { accent },
                        textColor = entry.textColor,
                        fillColor = entry.fillColor,
                        shape = entry.shape,
                        enabled = entry.enabled
                    )
                }
            }
        }

        AzDropdownEntry.Divider -> Unit // handled above
    }
    } // close the bounds-capture Box
}

/** Best-effort label for the tapped entry — same text the row currently renders. */
private fun entryLabel(entry: AzDropdownEntry): String = when (entry) {
    is AzDropdownEntry.Item -> entry.text
    is AzDropdownEntry.Toggle -> if (entry.isChecked) entry.toggleOnText else entry.toggleOffText
    is AzDropdownEntry.Cycler -> entry.selectedOption
    AzDropdownEntry.Divider -> ""
}

/**
 * Pins the dropped panel to the [dockingSide] **screen edge** and **drops it from the trigger**: it
 * opens downward from the trigger's bottom when there is room, otherwise upward from its top. Like
 * the rail, the side is physical ([AzDockingSide.LEFT] → left edge, [AzDockingSide.RIGHT] → right).
 */
private class AzDropdownEdgePositionProvider(
    private val dockingSide: AzDockingSide,
    private val anchorOverride: () -> IntRect? = { null },
) : PopupPositionProvider {
    override fun calculatePosition(
        anchorBounds: IntRect,
        windowSize: IntSize,
        layoutDirection: LayoutDirection,
        popupContentSize: IntSize
    ): IntOffset {
        val anchor = anchorOverride() ?: anchorBounds
        val x = if (dockingSide == AzDockingSide.LEFT) 0 else windowSize.width - popupContentSize.width
        val fitsBelow = anchor.bottom + popupContentSize.height <= windowSize.height
        val y = if (fitsBelow) {
            anchor.bottom
        } else {
            (anchor.top - popupContentSize.height).coerceAtLeast(0)
        }
        return IntOffset(x, y)
    }
}

/**
 * A standalone, hamburger-style drop-down menu, declared with the same opinionated DSL as the rail.
 *
 * The trigger is the **app icon** (auto-drawn exactly like the rail's header; its shape/size are set
 * via [AzDropdownMenuScope.azConfig], mirroring the rail's `azTheme`), dropped inline like any
 * widget. Tapping it unfolds a [Popup] panel of the items you declare in
 * [content]; the panel is presented as a slice of the rail ([AzDropdownDesign.RAIL]) or menu
 * ([AzDropdownDesign.MENU]), width-constrained to match, pinned to the [AzDockingSide] screen edge,
 * and dropping from the trigger. Tapping outside or pressing back folds it up.
 *
 * Configure and populate it through [AzDropdownMenuScope], like the rail:
 * ```
 * AzDropdownMenu(navController = navController) {
 *     azConfig(design = AzDropdownDesign.MENU, dockingSide = AzDockingSide.LEFT)
 *     azItem("Home", route = "home") { }
 *     azToggle(isChecked = dark, toggleOnText = "Dark", toggleOffText = "Light") { dark = it }
 *     azDivider()
 *     azItem("Sign out") { signOut() }
 * }
 * ```
 *
 * Items may declare a `route`; when set, tapping navigates the [navController] (so the drop-down can
 * drive an `AzNavHost`, just like the rail), then runs the item's callback.
 *
 * @param modifier Modifier applied to the trigger's box — place/position it like any widget.
 * @param navController Controller used to navigate item `route`s. Defaults to the enclosing
 *   `AzNavHost`'s controller when present.
 * @param expanded Optional controlled open-state. When null the menu manages its own state.
 * @param onExpandedChange Called whenever the open-state changes.
 * @param content The menu's configuration and items, declared via [AzDropdownMenuScope].
 */
@Composable
fun AzDropdownMenu(
    modifier: Modifier = Modifier,
    navController: NavController? = LocalAzNavHostScope.current?.navController,
    expanded: Boolean? = null,
    onExpandedChange: ((Boolean) -> Unit)? = null,
    content: AzDropdownMenuScope.() -> Unit
) {
    // Collect the DSL fresh each recomposition (no remembered mutable scope to reset).
    val scope = AzDropdownMenuScopeImpl().apply(content)
    val config = scope.config
    val entries = scope.entries

    var internalOpen by rememberSaveable { mutableStateOf(false) }
    val isOpen = expanded ?: internalOpen
    val setOpen: (Boolean) -> Unit = { value ->
        if (expanded == null) internalOpen = value
        onExpandedChange?.invoke(value)
    }

    // Full-screen About / More-from-Az reader state. The dropdown has no host/onscreen area, so its
    // About page is drawn as its own full-screen layer (above everything) rather than inline.
    var showAbout by rememberSaveable { mutableStateOf(false) }
    var showMoreFromAz by rememberSaveable { mutableStateOf(false) }
    // Per-entry window-space bounds, captured on each entry's globallyPositioned so the dissolve
    // overlay can render the label at its true screen position after the panel Popup tears down.
    val entryBounds = remember { androidx.compose.runtime.mutableStateMapOf<Int, androidx.compose.ui.geometry.Rect>() }
    // Dissolve overlay for the tapped entry that closes the panel (see AzNavRail's counterpart).
    // Owned by the host so the label can cross the whole window; null when standalone.
    val dissolveHost = LocalAzNavHostScope.current as? AzNavHostScopeImpl
    // A throwaway rail scope only supplies default theme tokens (accent/surface) to the reused
    // overlays; the dropdown declares no rail theme of its own.
    val overlayScope = remember { AzNavRailScopeImpl() }

    val haptic = LocalHapticFeedback.current
    val context = LocalContext.current
    // The repo backing the About reader: explicit override if set, else derived from the app
    // namespace. Never the AzNavRail library repo.
    val effectiveRepoUrl = remember(config.appRepositoryUrl, context.packageName) {
        config.appRepositoryUrl.ifBlank {
            GithubDocsRepository.repoUrlFromPackage(context.packageName) ?: config.appRepositoryUrl
        }
    }
    // Whether THIS menu is the surface that draws About. Claimed from the trigger's composition (not
    // the panel's) so the answer doesn't flip every time the panel opens and closes.
    val ownsAbout = rememberAzAboutOwnership(
        surface = AzAboutSurface.DROPDOWN_FOOTER,
        offered = config.showFooter && config.design == AzDropdownDesign.MENU,
        dedupe = config.dedupeAbout,
    )

    val maxPanelHeight = (LocalConfiguration.current.screenHeightDp * 0.8f).dp
    val panelWidth = if (config.design == AzDropdownDesign.RAIL) config.collapsedWidth else config.expandedWidth

    // The panel's own two colours, resolved once for the whole drop-down so the rows, the divider and
    // the footer are guaranteed to agree: the rail's opaque surface, and an accent that has been
    // checked against it.
    val panelColor = azPanelColor()
    val panelAccent = azReadableOn(panelColor, azAccent())

    // Where the trigger ends up. AUTO lifts it into the screen-title row whenever there is a host to
    // put it in; a standalone drop-down (no AzHostActivityLayout) has no title row, so it stays inline.
    val titleHost = LocalAzNavHostScope.current as? AzNavHostScopeImpl
    val hostsTrigger = titleHost != null && when (config.triggerPlacement) {
        AzDropdownTriggerPlacement.INLINE -> false
        AzDropdownTriggerPlacement.TITLE, AzDropdownTriggerPlacement.AUTO -> true
    }

    // The trigger's real window-space bounds, reported by whichever button ends up drawing it, so
    // the panel drops from the button the user tapped even when that button lives in the title row.
    var triggerBounds by remember { mutableStateOf<IntRect?>(null) }

    val positionProvider = remember(config.dockingSide) {
        AzDropdownEdgePositionProvider(config.dockingSide) { triggerBounds }
    }

    // The launcher icon, loaded exactly like the rail's header icon. Only AzDropdownTrigger.AppIcon
    // uses it.
    val appIcon = remember(context.packageName) {
        try { context.packageManager.getApplicationIcon(context.packageName) } catch (e: Exception) { null }
    }

    // One slot per drop-down. It carries the trigger's (comparable) look as snapshot state and its
    // behaviour as plain fields, so the title row can render a trigger that always calls back into
    // this composition without this composition having to re-publish a fresh lambda every frame.
    val slot = remember { AzTitleTriggerSlot() }
    slot.onTap = {
        setOpen(!isOpen)
        if (config.vibrate) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
    }
    slot.onBounds = { bounds -> triggerBounds = bounds }
    slot.publish(
        AzDropdownTriggerSpec(
            trigger = config.trigger,
            size = config.headerIconSize,
            iconShape = config.headerIconShape,
            appIcon = appIcon,
            textStyle = config.itemTextStyle,
        )
    )

    if (hostsTrigger) {
        DisposableEffect(titleHost, slot) {
            titleHost?.registerTitleTrigger(slot)
            onDispose { titleHost?.unregisterTitleTrigger(slot) }
        }
    }

    Box(modifier = modifier) {
        // The trigger itself, unless the host has taken it up to the title row — in which case
        // nothing is drawn here and only the dropped panel below still belongs to this call site.
        if (!hostsTrigger) {
            AzDropdownTriggerButton(slot)
        }

        // Keep the panel composed through the staggered exit so items can animate out before teardown.
        val rendered = rememberAzClosingState(
            open = isOpen,
            exit = config.itemExit,
            count = entries.size,
            staggerMs = config.entranceStaggerMs,
            durationMs = config.entranceDurationMs
        )
        if (rendered) {
            // Full-screen dim scrim behind the popup, only when the developer opted in. Rendered as its
            // own Popup so it covers everything the menu might sit above and dismisses the menu on tap.
            if (config.dimBehindMenu) {
                Popup(
                    onDismissRequest = { setOpen(false) },
                    properties = PopupProperties(focusable = false, dismissOnClickOutside = true),
                ) {
                    Box(
                        Modifier
                            .fillMaxSize()
                            .background(
                                androidx.compose.ui.graphics.Color.Black.copy(
                                    alpha = config.dimBehindMenuAlpha.coerceIn(0f, 1f),
                                )
                            )
                            .clickable { setOpen(false) }
                    )
                }
            }
            Popup(
                popupPositionProvider = positionProvider,
                onDismissRequest = { setOpen(false) },
                properties = PopupProperties(focusable = true, dismissOnClickOutside = true)
            ) {
                Surface(
                    // The host rail's panel colour when there is one, so a rail's own drop-down does
                    // not arrive in the app theme's surface instead of the rail's — and opaque either
                    // way. A menu you can read the app's artwork through is not a menu (see
                    // [azPanelColor]).
                    color = panelColor,
                    shape = RoundedCornerShape(12.dp),
                    // Material's tonal elevation tints the surface toward the theme's primary. On a
                    // panel that has just been told exactly what colour to be, that is the theme
                    // reaching back in; the shadow alone lifts it off the app.
                    tonalElevation = 0.dp,
                    shadowElevation = 8.dp
                ) {
                    val scrollState = rememberScrollState()
                    val dismiss = { setOpen(false) }
                    Column(
                        modifier = Modifier
                            .width(panelWidth)
                            .heightIn(max = maxPanelHeight)
                            .verticalScroll(scrollState)
                            .then(if (config.design == AzDropdownDesign.RAIL) Modifier.padding(8.dp) else Modifier),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        val entryDensity = androidx.compose.ui.platform.LocalDensity.current
                        entries.forEachIndexed { index, entry ->
                            // If this entry was the one tapped-to-close, render an invisible
                            // placeholder the same height as the captured entry so the panel
                            // stays occupied while the dissolve overlay animates its label. A bare
                            // `Spacer` doesn't draw or hit-test — it just holds the layout so the
                            // rows below don't snap upward during the dissolve.
                            val dissolvingHere = dissolveHost?.dissolving?.takeIf { it.itemId == "azdd:$index" }
                            if (dissolvingHere != null) {
                                Spacer(
                                    Modifier.height(
                                        with(entryDensity) { dissolvingHere.bounds.height.toDp() }
                                    )
                                )
                                return@forEachIndexed
                            }
                            AzDropdownEntryItem(
                                index = index,
                                count = entries.size,
                                visible = isOpen,
                                entry = entry,
                                config = config,
                                navController = navController,
                                accent = panelAccent,
                                dismiss = dismiss,
                                onBoundsCapture = { idx, rect -> entryBounds[idx] = rect },
                                onDissolveTap = { idx, text ->
                                    val bounds = entryBounds[idx]
                                    if (bounds != null) {
                                        dissolveHost?.dissolve(
                                            com.hereliesaz.aznavrail.internal.DissolveState(
                                                itemId = "azdd:$idx",
                                                text = text,
                                                bounds = bounds,
                                            )
                                        )
                                    }
                                },
                            )
                        }
                        // The expanded-menu design carries the rail's footer (About / Feedback / @HereLiesAz).
                        if (config.design == AzDropdownDesign.MENU && config.showFooter) {
                            AzDivider(color = panelAccent)
                            AzDropdownFooter(
                                repoUrl = effectiveRepoUrl,
                                footerColor = panelAccent,
                                onAboutClick = if (config.inAppAbout && effectiveRepoUrl.isNotBlank()) {
                                    { dismiss(); showAbout = true }
                                } else null,
                                showAbout = ownsAbout,
                                visible = isOpen,
                                menuItemCount = entries.size,
                                staggerMs = config.entranceStaggerMs,
                                durationMs = config.entranceDurationMs,
                                easing = config.entranceEasing,
                            )
                        }
                    }
                }
            }
        }

        // Full-screen About reader / More-from-Az carousel for the dropdown. Drawn in its own Popup
        // so it escapes the inline trigger box and covers the whole window (the dropdown has no host
        // onscreen area). Safe-zone insets come from the window (system bars union display cutout)
        // since there is no host to compute the rail's 10%/20% zones.
        if (showAbout || showMoreFromAz) {
            val windowInsets = azWindowSafeInsets()
            Popup(
                popupPositionProvider = AzFullScreenPopupPositionProvider,
                onDismissRequest = { showAbout = false; showMoreFromAz = false },
                properties = PopupProperties(focusable = true, dismissOnClickOutside = false)
            ) {
                CompositionLocalProvider(
                    LocalAzSafeZones provides AzSafeZones(
                        top = windowInsets.top,
                        bottom = windowInsets.bottom,
                        start = windowInsets.start,
                        end = windowInsets.end
                    )
                ) {
                    Box(Modifier.fillMaxSize()) {
                        if (showAbout) {
                            AboutOverlay(
                                repoUrl = effectiveRepoUrl,
                                scope = overlayScope,
                                onOpenMoreFromAz = { showMoreFromAz = true },
                                onDismiss = { showAbout = false },
                            )
                        }
                        // More-from-Az draws above About; dismissing it returns to About underneath.
                        if (showMoreFromAz) {
                            MoreFromAzOverlay(
                                jsonUrl = overlayScope.advancedConfig.moreFromAzJsonUrl,
                                scope = overlayScope,
                                onDismiss = { showMoreFromAz = false },
                            )
                        }
                    }
                }
            }
        }
    }
}

/** Positions a [Popup] at the window origin so its `fillMaxSize` content covers the whole screen. */
private val AzFullScreenPopupPositionProvider = object : PopupPositionProvider {
    override fun calculatePosition(
        anchorBounds: IntRect,
        windowSize: IntSize,
        layoutDirection: LayoutDirection,
        popupContentSize: IntSize
    ): IntOffset = IntOffset(0, 0)
}
