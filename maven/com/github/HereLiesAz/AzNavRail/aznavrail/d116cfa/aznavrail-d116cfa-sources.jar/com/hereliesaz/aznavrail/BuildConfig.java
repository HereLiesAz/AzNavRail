/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.hereliesaz.aznavrail;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "com.hereliesaz.aznavrail";
  public static final String BUILD_TYPE = "release";
}
